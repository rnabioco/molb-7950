# images for slide content

Put images in this directory and use them in slide content via:

```
library(here)
knitr::include_graphics(here("img/dog.png"))
```
